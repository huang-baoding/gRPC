学习写proto文件
proto文件生成go代码
将proto里定义的消息转为二进制文件
将proto里定义的消息转为json文件

在file_test.go文件中run test就可以测试实现的功能