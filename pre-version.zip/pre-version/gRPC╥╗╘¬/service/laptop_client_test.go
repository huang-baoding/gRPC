package service_test

import (
	"context"
	"grpctest/pb"
	"grpctest/sample"
	"grpctest/serializer"
	"grpctest/service"
	"net"
	"testing"

	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
)

func TestClientCreateLaptop(t *testing.T) {
	t.Parallel()

	//获取服务器和地址
	laptopServer, serverAddress := startTestLaptopServer(t)
	//返回一个laptop用来做测试
	laptopClient := newTestLaptopClient(t, serverAddress)

	laptop := sample.NewLaptop()
	expectedID := laptop.Id         //保存ID用来比较
	req := &pb.CreateLaptopRequest{ //使用laptop创建一个新的请求对象
		Laptop: laptop,
	}

	res, err := laptopClient.CreateLaptop(context.Background(), req)
	require.NoError(t, err)
	require.NotNil(t, res)               //测试的响应不应该为nil
	require.Equal(t, expectedID, res.Id) //这两个的值应该相等

	//确保laptop确实存储在服务器上
	other, err := laptopServer.Store.Find(res.Id)
	require.NoError(t, err)
	require.NotNil(t, other)

	//检查保存的laptop是否和我们发送的laptop相同
	requireSameLaptop(t, laptop, other)

}

func newTestLaptopClient(t *testing.T, serverAddress string) pb.LaptopServiceClient { ///////////
	//拨打服务器地址
	conn, err := grpc.Dial(serverAddress, grpc.WithInsecure) //只是测试，使用不安全的连接
	require.NoError(t, err)
	return pb.NewLaptopServiceClient(conn) ////////////////////
}

//检查保存的laptop是否和我们发送的laptop相同
func requireSameLaptop(t *testing.T, laptop1 *pb.Laptop, laptop2 *pb.Laptop) {
	// require.Equal(t, laptop, other)//会失败，因为有一些默认字段
	//正确的比较方法是把他们转化为json格式，并比较两个输出的字符串

	json1, err := serializer.ProtobufToJSON(laptop1)
	require.NoError(t, err)

	json2, err := serializer.ProtobufToJSON(laptop2)
	require.NoError(t, err)

	require.Equal(t,json1,json2)     ///////////////////
}

//启动gRPC服务
func startTestLaptopServer(t *testing.T) (*service.LaptopServer, string) {
	//封装对lptop的操作
	laptopServer := service.NewLaptopServer(service.NewInMemoryLaptopStore())

	//创建gRPC服务器/
	grpcServer := grpc.NewServer()
	//在grpc服务器上注册laptop服务器
	pb.RegisterLaptopServiceServer(grpcServer, laptopServer)

	//创建监听器用来监听tcp
	listener, err := net.Listen("tcp", ":0") //0表示可以分配给它任何可用的端口
	require.NoError(t, err)

	//监听是阻塞调用，我们需要在goroutine里使用它
	go grpcServer.Serve(listener) ///////////监听

	//返回laptop服务器和监听的地址字符串
	return laptopServer, listener.Addr().String()

}
