//实现对存储的操作，save存入内存，find在内存中查找
package service

import (
	"errors"
	"fmt"
	"grpctest/pb"
	"sync"

	"github.com/jinzhu/copier"
)

var ErrAlreadyExists = errors.New("record already exists")

//因为有不同的store，我们用接口来定义的它的功能
type LaptopStore interface {
	//save the laptop to the store
	Save(laptop *pb.Laptop) error
	//通过id查找store里是否存在此laptop
	Find(id string) (*pb.Laptop, error)
}

//定义一个结构装实现LapStore中定义的体封函数（保存到store中，和查找...）
type InMemoryLaptopStore struct {
	// 因为会有大量的并发存储，我们使用互斥锁保证并发安全
	mutex sync.RWMutex
	//key存储laptop的id
	//值是laptop对象（值里同样包含id）
	data map[string]*pb.Laptop
}

//如果之后我们想将laptop保存到数据库中，我们可以实现另一个DBLLaptopStore来做到
//type DBLLaptopStore struct{ ... }

//返回一个&InMemoryLaptopStore
func NewInMemoryLaptopStore() *InMemoryLaptopStore {
	return &InMemoryLaptopStore{
		data: make(map[string]*pb.Laptop),
	}
}

//将laptop保存到store
func (store *InMemoryLaptopStore) Save(laptop *pb.Laptop) error {
	store.mutex.Lock()         //先加锁
	defer store.mutex.Unlock() //别忘了加锁的同时defer解锁

	if store.data[laptop.Id] != nil { //如果store中已经有了一样的id，则不存储并返回错误
		return ErrAlreadyExists
	}

	//id不存在的情况，我们保存到data字典中
	//为了安全起见，我们对laptop对象进行深度复制
	other := &pb.Laptop{}
	err := copier.Copy(other, laptop)
	if err != nil {
		return fmt.Errorf("cannot copy laptop data:%w", err)
	}

	store.data[other.Id] = other
	return nil
}

func (store *InMemoryLaptopStore) Find(id string) (*pb.Laptop, error) {
	//访问内存的时候需要先上锁
	store.mutex.Lock()
	defer store.mutex.Unlock()

	//通过id从map里找到laptop
	laptop := store.data[id]
	if laptop == nil {
		return nil, nil
	}

	//找到后我们应该将其深刻复制给另一个对象
	other := &pb.Laptop{}
	err := copier.Copy(other, laptop)
	if err != nil {
		return nil, fmt.Errorf("Can not copy laptop data:%w", err)
	}
	return other, nil
}
