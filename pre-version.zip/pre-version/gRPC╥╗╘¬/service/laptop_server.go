package service

import (
	"context"
	"errors"
	"grpctest/pb"
	"log"
	"time"

	"github.com/google/uuid"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

//定义一个结构体封装server的方法---服务器
type LaptopServer struct {
	Store LaptopStore			//一个接口，里面有存储和查找函数
}

//返回一个&laptop
func NewLaptopServer(store LaptopStore) *LaptopServer {
	return &LaptopServer{store}
}

//一元rpc//////////////////////////////////////////////////
func (server *LaptopServer) CreateLaptop(///////////////////////
	ctx context.Context,
	req *pb.CreateLaptopRequest,
) (*pb.CreateLaptopReponse, error) {
	laptop := req.GetLaptop()//得到来自客户端的req（CreateLaptopRequest）中定义的laptop字段的值
	log.Printf("receive a create-laptop with id:%s", laptop.Id)

	if len(laptop.Id) > 0 {
		//检查是否是一个有效的uuid
		_, err := uuid.Parse(laptop.Id)//解析uuid，如果err不为空表示解析出错
		if err != nil {
			//status是rpc的状态码子包，可以返回一些常见错误
			return nil, status.Errorf(codes.InvalidArgument, "laptop ID is not a valid uuid:%v", err)
		}
	} else {
		id, err := uuid.NewRandom()
		if err != nil {
			//codes.Internal表示是服务器内部的错误
			return nil, status.Errorf(codes.Internal, "can not generate a new laptop uuid:%v", err)
		}
		laptop.Id = id.String()
	}

	//假设在这里做一些繁重的处理。
	time.Sleep(2*time.Second)//用来测试客户端的超时检测功能。
	if ctx.Err()==context.Canceled{
		log.Print("Request is cancel")
		return nil,status.Error(codes.Canceled,"request is canceled")
	}
	//实现客户端退出后，服务器不会继续保存laptop


	//检查服务器上的上下文的错误。
	//如果出现了DeadlineExceeded错误,我们将在此打印日志，并向客户端返回错误状态码二维码
	if ctx.Err()==context.DeadlineExceeded{
		log.Print("deadline id exceeded")
		return nil,status.Error(codes.DeadlineExceeded,"deadline id exceeded")
	}//客户端收到此错误后，就不会继续保存laptop


	//一般我们在这时候应该把laptop存储到数据库中，（留着之后实现）////////////////

	//现在我们将laptop保存到store（内存）中
	err := server.Store.Save(laptop)//server结构体实现了Store接口，此接口中有函数Save（）
	if err != nil {
		//检查是否因为记录已存在而出错
		code := codes.Internal//(codes.Internal是服务器错误)/////////////////////////////////
		if errors.Is(err, ErrAlreadyExists) {///////////////////
			code = codes.AlreadyExists//(已经存在)
		}
		//如果有错误，我们将错误返回给客户端
		return nil, status.Errorf(code, "cannot ssave laptop to the store:%v", err)
	}

	log.Printf("save laptop with id:%v", laptop.Id)

	//使用laptopid创建一个新的响应对象id,然后将此对象返回给调用者（client）
	res := &pb.CreateLaptopReponse{
		Id: laptop.Id,
	}
	return res, nil
}
