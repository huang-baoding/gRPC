package main

import (
	"context"
	"flag"
	"grpctest/pb"
	"grpctest/sample"
	"log"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func main() {
	//首先是从命令行参数中获取服务器地址。
	serverAddress := flag.String("address", "", "the server address")
	flag.Parse()
	//写一个简单的日志，说我们正在拨打这个服务器
	log.Printf("dial server %s", *serverAddress)

	//使用输入地址调用grpc.Dial()函数
	conn, err := grpc.Dial(*serverAddress, grpc.WithInsecure()) //创建的是一个不安全的链接。
	if err != nil {
		log.Fatal("cannot dial server:%v", err)
	}

	//使用连接创建一个新的laptop客户端对象
	laptopClient := pb.NewLaptopServiceClient(conn)

	//生成一个新的laptop请求对象
	laptop := sample.NewLaptop()
	req := &pb.CreateLaptopRequest{
		Laptop: laptop,
	}

	//为请求设置超时
	//在goalng中,我们将使用context来做到这一点。
	//该函数返回一个上下文和一个取消对象。
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	//使用请求和背景上下文调用notebookClient.Createlaptop()
	res, err := laptopClient.CreateLaptop(ctx, req)
	if err != nil {
		//如果发生错误，我们将其转换为状态对象,这样我们就可以检查返回的状码。
		st, ok := status.FromError(err)
		if ok && st.Code() == codes.AlreadyExists {
			//如果已经存在,写个简单的日志记录一下就可以了。
			log.Print("laptop already exists")
		} else {
			//否则记录这个严重的错误。
			log.Fatal("can not create laptop:%v", err)
		}
	}

	//全部顺利执行后，我们只需要写一个日志，说明笔记本电脑是用这个ID创建的
	log.Printf("created laptop with id:%s", res.Id)
}
