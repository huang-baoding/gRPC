package main

import (
	"flag"
	"fmt"
	"grpctest/pb"
	"grpctest/service"
	"log"
	"net"

	"google.golang.org/grpc"
)

func main() {
	//使用flag.Int从命令行参数获取端口
	port := flag.Int("port", 0, "the server port")
	//解析标志
	flag.Parse()
	//打印一个简单的日志
	log.Printf("start server on port %d", *port)

	laptopStore := service.NewInMemoryLaptopStore()
	imageStore := service.NewDiskImageStore("./img/") //在img文件夹中保存上传的图像
	//使用内存存储创建一个新的laptop服务器对象
	ratingStore:=service.NewInMemoryRatingStore()
	LaptopServer := service.NewLaptopServer(laptopStore, imageStore,ratingStore)
	//创建一个新的gRPC服务器
	grpcServer := grpc.NewServer()
	//向gRPC服务器上注册laptop服务器
	pb.RegisterLaptopServiceServer(grpcServer, LaptopServer)

	// 用之前得到的端口创建一个地址字符串
	address := fmt.Sprintf("0.0.0.0:%d", *port)
	//监听此tcp上的连接
	listen, err := net.Listen("tcp", address)
	if err != nil {
		log.Fatal("can not start server:%v", err)
	}

	//调用grpcServer.Server()来启动服务
	err = grpcServer.Serve(listen)
	if err != nil {
		log.Fatal("can not start server:%v", err)
	}
}
