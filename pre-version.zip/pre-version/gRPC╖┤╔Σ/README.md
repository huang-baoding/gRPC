serializer文件夹实现的是将laptop对象序列化为文件
tmp文件夹是存放测试serializer文件夹功能后生成的二进制文件和json文件

双向流：客户端和服务端并行发送多个请求和多个响应。为客户端编写一个API以对分数从1到10的笔记本电脑流进行评分。服务器将以每台每台笔记本电脑的平均分数流进行响应。

用Evans客户端来玩转gRPC的反射(Evans还没安装成功)
gRPC反射是服务器的可选扩展，用于帮助客户端构建请求，而无需事先生成存根，这对于客户端在实际实施之前探索gRPC API非常有用
在golang服务器中使用：
    先导入反射包："google.golang/grpc/reflection"
    然后调用反射注册:reflection.Register(grpcServer)